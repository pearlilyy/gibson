//Gibson footer.js

$(document).ready(function(){
    
    
    
    
    /*function familyFlow (){
        
        $('.family_site ul').animate({
            marginLeft: '35%'
        },4000, 'linear');
        
        $('.family_site ul').animate({
            marginLeft: '0%'
        },4000, 'linear');
    }
    
    
    var flowSet = setInterval(function(){
        familyFlow();
    });
    
    $('.family_site>ul').mouseenter(function(){
        clearInterval(flowSet);
    }).mouseleave(function(){
        flowSet = setInterval(function(){
            familyFlow();
        },2000)
    });*/
    
}); //jQuery